
// Minimal top‑down survival using heroine sprites + simple zombies.
// Move with virtual joystick (touch drag on left half), shoot by tapping right half.

const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d', { alpha: false });
function resize(){ canvas.width=innerWidth; canvas.height=innerHeight }
addEventListener('resize', resize); resize();

const FRAME_W = 128, FRAME_H = 160;
const DIRS = ['north','northeast','east','southeast','south','southwest','west','northwest'];
function dirFromVec(x,y){
  const a = Math.atan2(y, x); // -PI..PI, x right
  const deg = (a*180/Math.PI+360)%360;
  const idx = Math.round(deg/45)%8;
  return ['east','northeast','north','northwest','west','southwest','south','southeast'][idx];
}
function loadImage(src){ return new Promise(r=>{ const i=new Image(); i.onload=()=>r(i); i.src=src; });}

// HERO LOAD
const HERO_IDLE = {};
async function loadHero(){
  for (const d of DIRS){
    HERO_IDLE[d] = await loadImage(`assets/hero/idle/hero_idle_${d}.png`);
  }
}
const hero = { x: innerWidth/2, y: innerHeight/2, vx:0, vy:0, speed:2.2, dir:'south', anim:0, hp:100
};

// ZOMBIES
const ZSETS = [
  {name:'worker', color:'#6a6', speed:1.1},
  {name:'nurse', color:'#ccc', speed:1.0},
  {name:'burned', color:'#777', speed:1.2},
  {name:'rotting', color:'#744', speed:0.9}
];
const Z_ANIMS = {}; // {set:{idle:{dir:img}, walk:{dir:img}}}
async function loadZombies(){
  for (const z of ZSETS){
    Z_ANIMS[z.name] = { idle:{}, walk:{} };
    for (const d of DIRS){
      Z_ANIMS[z.name].idle[d] = await loadImage(`assets/zombies/${z.name}/idle/${z.name}_idle_${d}.png`);
      Z_ANIMS[z.name].walk[d] = await loadImage(`assets/zombies/${z.name}/walk/${z.name}_walk_${d}.png`);
    }
  }
}

// FX
const FX = {};
async function loadFX(){
  FX.blood = await loadImage('assets/fx/blood_splatter.png'); // 3 frames
}

let enemies = [];
let bullets = [];
let kills = 0, wave = 1;

function spawnZombie(){
  const zset = ZSETS[Math.floor(Math.random()*ZSETS.length)];
  const side = Math.floor(Math.random()*4);
  let x=0,y=0;
  if(side===0){ x=-100; y=Math.random()*canvas.height; }
  if(side===1){ x=canvas.width+100; y=Math.random()*canvas.height; }
  if(side===2){ x=Math.random()*canvas.width; y=-100; }
  if(side===3){ x=Math.random()*canvas.width; y=canvas.height+100; }
  enemies.push({ x,y, set:zset.name, speed:zset.speed, hp:30, anim:0, dir:'south'});
}

function shoot(){
  const angle = Math.atan2(aim.y, aim.x);
  bullets.push({ x:hero.x, y:hero.y-20, vx:Math.cos(angle)*5, vy:Math.sin(angle)*5, life:120 });
}

const hudHp = document.getElementById('hp');
const hudKills = document.getElementById('kills');
const hudWave = document.getElementById('wave');

// Touch controls (virtual stick + aim by touch on right half)
let stick={active:false, sx:0, sy:0, x:0, y:0}; let aim={x:1,y:0};
canvas.addEventListener('touchstart', e=>{
  for(const t of e.changedTouches){
    const x=t.clientX, y=t.clientY;
    if(x<innerWidth/2){ stick.active=true; stick.sx=x; stick.sy=y; stick.x=0; stick.y=0; }
    else { aim.x = (x-hero.x); aim.y=(y-hero.y); shoot(); }
  }
});
canvas.addEventListener('touchmove', e=>{
  for(const t of e.changedTouches){
    const x=t.clientX, y=t.clientY;
    if(stick.active){ stick.x = x-stick.sx; stick.y = y-stick.sy; }
  }
});
canvas.addEventListener('touchend', e=>{ stick.active=false; stick.x=0; stick.y=0; });

// Mouse for desktop
canvas.addEventListener('mousemove', e=>{ aim.x=e.clientX-hero.x; aim.y=e.clientY-hero.y; });
canvas.addEventListener('mousedown', e=>{ if(e.button===0) shoot(); });

function update(){
  // hero movement
  const mx = Math.max(-1, Math.min(1, stick.x/60));
  const my = Math.max(-1, Math.min(1, stick.y/60));
  hero.vx = mx*hero.speed; hero.vy = my*hero.speed;
  hero.x += hero.vx; hero.y += hero.vy;
  if(hero.vx||hero.vy){ hero.dir = dirFromVec(hero.vx, hero.vy); }
  // bullets
  for(const b of bullets){ b.x+=b.vx; b.y+=b.vy; b.life--; }
  bullets = bullets.filter(b=>b.life>0 && b.x>-50 && b.x<canvas.width+50 && b.y>-80 && b.y<canvas.height+80);
  // enemies
  for(const z of enemies){
    const dx = hero.x - z.x, dy = hero.y - z.y;
    const dn = Math.hypot(dx,dy) || 1;
    z.x += (dx/dn) * z.speed;
    z.y += (dy/dn) * z.speed;
    z.dir = dirFromVec(dx,dy);
    // hit test bullets
    for(const b of bullets){
      if(Math.abs(b.x-z.x)<24 && Math.abs(b.y-z.y)<32){ z.hp-=20; b.life=0; }
    }
  }
  // deaths
  const alive=[];
  for(const z of enemies){
    if(z.hp<=0){ kills++; } else alive.push(z);
  }
  enemies = alive;
  // waves
  if(enemies.length<10) spawnZombie();
  document.getElementById('kills').textContent = kills;
}

function drawSpriteSheet(img, frames, x,y){
  const t = performance.now();
  const idx = Math.floor((t/1000)*4) % frames;
  ctx.drawImage(img, idx*FRAME_W, 0, FRAME_W, FRAME_H, x-FRAME_W/2, y-FRAME_H/2, FRAME_W, FRAME_H);
}

async function main(){
  await loadHero(); await loadZombies(); await loadFX();
  requestAnimationFrame(loop);
}
function loop(){
  update();
  ctx.fillStyle = '#050505'; ctx.fillRect(0,0,canvas.width,canvas.height);
  // draw hero
  const himg = HERO_IDLE[hero.dir] || HERO_IDLE['south'];
  drawSpriteSheet(himg, 2, hero.x, hero.y);
  // draw enemies
  for(const z of enemies){
    const set = Z_ANIMS[z.set];
    const zimg = set.walk[z.dir] || set.walk['south'];
    drawSpriteSheet(zimg, 4, z.x, z.y);
  }
  requestAnimationFrame(loop);
}
main();
